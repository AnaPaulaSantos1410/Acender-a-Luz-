// criando os elementos do dom
const imgOlhos = document.getElementById("imgOlhos");
const imgLampada = document.getElementById("imgLampada");
const btnLigar = document.getElementById("btnLigar");
const btnDesligar = document.getElementById("btnDesligar");

//Respondendo eventos
btnLigar.addEventListener("click", () => {
  debugger;
  imgLampada.src = "./img/ligada.jpg";
  imgOlhos.src = "./img/beijaflor.gif";
});

btnDesligar.addEventListener("click", () => {
  debugger;
  imgLampada.src = "./img/desligada.jpg";
  imgOlhos.src = "./img/gato.gif";
});


